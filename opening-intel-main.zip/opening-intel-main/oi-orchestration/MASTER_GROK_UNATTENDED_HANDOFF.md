# OI Master Coordination / Grok - unattended execution handoff

Set:

`MASTER_UNATTENDED_EXECUTION_OVERSIGHT = ACTIVE`

`REPOSITORY_STATE = PRIMARY_COORDINATION_CHANNEL`

`USER_SCREENSHOT_RELAY = NOT_REQUIRED_FOR_NORMAL_COORDINATION`

`MANUFACTURER_EXECUTION_OWNERSHIP = PRESERVED`

## Runtime

`main` now owns the external unattended execution architecture. The GitHub Actions workflow `OI Unattended Manufacturer Worker` runs on a 30-minute schedule and discovers executable manufacturer lanes directly from their durable branch checkpoints.

The executor does not make Grok the manufacturer execution owner. Grok remains the coordination owner and should consume resulting branch commits, checkpoints, manifests, measurement states, imagery states, and persistence states.

## Current lane discovery behavior

Only lanes with explicit executable checkpoint signals are scheduled. Controlled dependency holds, terminal evidence ceilings, and stale top-level labels do not create work by themselves.

At the Phase 2 live activation check, the executable lanes were:

`CAL_ROYAL`

`HAGER`

ASSA ABLOY was correctly excluded after its missing-published-dimension backfill reached `CONTROLLED_DEPENDENCIES_ONLY`; `IMAGERY_IN_PROGRESS_CONTROLLED_HOLD` is not treated as executable imagery.

Dormakaba, Pamex, and terminal Allegion sub-lanes remain dormant until governed state-changing evidence makes work executable.

These are checkpoint-derived observations, not permanent manufacturer classifications. Re-evaluate from current repository state every cycle.

## Infrastructure blocker classification

If the scheduled executor reports that `OPENAI_API_KEY` is unavailable, classify:

`UNATTENDED_EXECUTION_INFRASTRUCTURE_BLOCKER = API_CREDENTIAL_NOT_CONFIGURED`

Do not convert this into a manufacturer evidence, identity, geometry, measurement, or imagery hold.

Do not ask individual manufacturer lanes to solve an infrastructure credential problem.

## Commit ingest

When commits authored by the unattended executor appear on a manufacturer branch:

1. ingest the new manufacturer checkpoint
2. preserve the manufacturer execution owner
3. refresh measurement and imagery facets separately
4. ingest new artifact hashes/index/manifest records
5. remove satisfied resume work from the master view
6. do not create duplicate manual requeue records for work already advanced by the executor
7. surface only genuine unresolved blockers or validation failures to the user

## Imagery candidate states

The unattended imagery service may create:

`READY_TO_GENERATE`

`CANDIDATE_GENERATED_UNVERIFIED`

`QA_PASSED_CANDIDATE_NOT_CANONICAL`

`QA_REJECTED`

`QA_CONTROLLED_HOLD`

These are not equivalent to `IMAGERY_COMPLETE`.

Canonical completion still requires the manufacturer's existing governed promotion, visual/source-fidelity QA, persistent artifact, SHA256, imagery index, manifest, and Git commit chain.

A contact sheet never substitutes for required standalone canonical views.

## User interruption policy

Routine unattended run completion, checkpointing, generated candidates, QA rejections, controlled per-identity holds, and branch commits should not require the user to transport screenshots between lanes.

Surface user action only for genuine cross-workstream blockers such as authentication/credential setup, paid/licensed access decisions, destructive or consequential approvals, or unavailable authoritative evidence that cannot be recovered through governed sources.

The user's role is exception handling, not routine agent transport.
