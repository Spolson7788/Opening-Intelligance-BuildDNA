# Opening Intelligence resumable execution — Phase 1

Status: **dry run only**. Paid/model execution is disabled.

This control layer removes the user from routine checkpoint transport. It does **not** make ChatGPT Work conversations persistent background workers. A later authorized external executor can consume the durable queue created here.

## Existing controls reused

The repository already has manufacturer work queues/checkpoints and the cross-workstream `oi-imagery/IMAGERY_WORK_QUEUE.csv`. Phase 1 does not replace those. `oi-orchestration/` adds only the execution-resume/claim layer needed after a lane emits `PLATFORM_EXECUTION_LIMIT_REACHED`.

## Files

- `LANE_REGISTRY.json` — governed active branch/checkpoint locations and execution ownership.
- `WORKSTREAM_RESUME_QUEUE.json` — durable resumable jobs. `paid_execution_enabled` is locked `false` in Phase 1.
- `EXECUTION_CLAIMS.json` — active claim/lock records.
- `EXECUTION_HEARTBEATS.json` — liveness/progress records for claimed jobs.
- `EXECUTOR_STATE.json` — Phase 1 capability/readiness flags and safety limits.
- `RETRY_QUEUE.json` — transient retry candidates only.
- `EXECUTION_AUDIT_LOG.jsonl` — append-only orchestration events.
- `CURRENT_CHECKPOINT.json` — engineering workstream checkpoint.
- `MASTER_COORDINATION_HANDOFF.md` — integration contract for OI — Master Coordination / Grok.
- `examples/platform-limit-checkpoint.json` — deterministic simulated checkpoint used by the dry-run executor.

## Current lane registry

The registry points at the existing controlled branches for Cal-Royal, ASSA ABLOY, Dormakaba, Hager, Pamex, Falcon, Ives, Glynn-Johnson and the master canonical-imagery branch. Exact row/product ownership remains controlled by the manufacturer workstream itself; the registry does not authorize cross-lane execution.

## Job lifecycle

`QUEUED | PLATFORM_LIMITED | RETRY -> CLAIMED -> RUNNING -> COMPLETE`

Alternative terminal/control states:

- `BLOCKED`
- `FAILED_VALIDATION`
- `SATISFIED_BY_EXISTING_STATE`

A claim is scoped to the job's `authorized_manufacturer_group`. Cross-manufacturer execution is rejected unless a future explicit handoff layer authorizes it.

## Checkpoint normalization

Manufacturer `CURRENT_CHECKPOINT.json` files are not identical. `normalizeLaneCheckpoint` maps common current fields into the stable `PlatformLimitCheckpoint` schema. A platform-limit event must be explicit; ordinary terminal/hold checkpoints are **not** automatically queued.

The checkpoint commit is mandatory input so a future executor can resume from a deterministic Git state.

## Idempotent resume

Before any real executor is enabled it must:

1. Load the checkpoint commit and current branch state.
2. Inspect durable artifacts, hashes, indexes and manifests.
3. Determine the exact first unfinished task.
4. Skip work already satisfied by durable state.
5. Persist accepted work incrementally before advancing.

For canonical imagery the governing chain remains:

`generate -> visual QA -> source-fidelity QA -> persistent file -> SHA256 -> index -> commit`

A `/workspace` path or chat preview is not completion.

## Stale claims

Claims use heartbeats. Phase 1 defaults to a 15-minute stale window in code. A stale claim is released to `RETRY`, preventing a dead worker from owning a job indefinitely.

## Queue ingestion

A normalized platform-limit checkpoint can be added to the durable queue with:

```bash
npm run orchestrator:ingest -- path/to/checkpoint.json
```

The ingest command uses stable IDs and is duplicate-safe for the same checkpoint/resume state.

## Dry run

Run:

```bash
npm run orchestrator:dry-run
```

or provide a checkpoint file:

```bash
npm run orchestrator:dry-run -- path/to/checkpoint.json
```

The dry-run executor:

- ingests a platform-limit checkpoint,
- creates a stable resume/job ID,
- claims only matching manufacturer work,
- starts the simulated job,
- proves completed checkpointed work is not duplicated,
- simulates the first unfinished task,
- emits a deterministic synthetic commit identifier,
- releases the claim,
- performs **no model/API calls and no paid execution**.

## CI validation

`.github/workflows/orchestrator-dry-run.yml` type-checks the repository, runs the isolated orchestrator tests without database setup, and executes the simulated platform-limit resume. It has read-only repository permissions.

## Phase 2 boundary

Phase 2 may connect an authorized CI/container/VM worker or supported model/API executor. That requires separate approval for credentials, secrets, budgets and paid execution. No such capability is enabled by this branch.
