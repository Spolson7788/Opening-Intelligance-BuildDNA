# Opening Intelligence Phase 3 - unattended governed imagery candidates

This phase extends the around-the-clock manufacturer worker so a lane can request image production only after exact identity and a specific visible view have independently passed the existing imagery gate.

## Lifecycle

`VIEW_GEOMETRY_LOCKED`

`-> READY_TO_GENERATE request`

`-> GPT-Image-2 candidate generation/edit with high-fidelity source inputs when available`

`-> CANDIDATE_GENERATED_UNVERIFIED`

`-> GPT-5.6 Sol visual/source-fidelity QA`

`-> QA_PASSED_CANDIDATE_NOT_CANONICAL | QA_REJECTED | QA_CONTROLLED_HOLD`

`-> next manufacturer-lane cycle validates nonvisual gate and promotes only eligible QA-passed candidates through the existing canonical persistence chain`

A generated candidate never receives canonical credit merely because the API call succeeded.

## Source fidelity

When the request lists exact governed source images, the generator uses the image edit endpoint with `input_fidelity=high`. Up to eight lane-owned source images are supplied. When no image source is available, a text-grounded candidate may be generated, but unattended visual QA places it on hold rather than granting source-fidelity credit.

The generation model is pinned by default to `gpt-image-2-2026-04-21` for reproducibility. Output is PNG and candidates remain isolated beneath the manufacturer's `artifacts/imagery-candidates/` tree.

## Visual QA

Separate QA uses `gpt-5.6-sol` with image inputs and a strict JSON-schema result. PASS requires all of:

- visible geometry match
- source fidelity match
- requested view match
- no meaningful identity ambiguity
- no unexplained added product features

Any missing exact source image, insufficient evidence, or ambiguous visual result becomes `QA_CONTROLLED_HOLD`.

## Canonical persistence

QA PASS still is not `IMAGERY_COMPLETE`. The owning manufacturer lane must on a later cycle apply its existing controls and, when defensible:

1. promote the candidate to the intended canonical artifact path
2. run/update required visual/source-fidelity records
3. compute SHA256
4. update the imagery index
5. update the manifest/checkpoint
6. allow the unattended outer workflow to commit and push

The contact sheet rule is unchanged: a contact sheet is supplemental and cannot substitute for the required standalone canonical view files.

## Cost guardrails

Each scheduled lane cycle generates at most two image candidates and performs at most two visual QA evaluations by default. These values are environment-configurable. The existing 30-minute scheduler and maximum three parallel lanes remain in effect.

## Security

The manufacturer agent never receives a reusable GitHub write credential. Image/API credentials are supplied only as GitHub Actions secrets to the isolated execution steps. The final repository diff still must remain entirely inside the owning manufacturer's allowed write root.
