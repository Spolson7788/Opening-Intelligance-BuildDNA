# Opening Intelligence Phase 2 - around-the-clock unattended execution

Phase 2 converts the Phase 1 deterministic resume controls into a scheduled external executor.

## Runtime

The default scheduler is GitHub Actions and runs every 30 minutes. Each cycle discovers lane checkpoints directly from the governed manufacturer branches. Explicit active signals are evaluated before stale broad terminal labels so newer nested work, such as ASSA ABLOY measurement backfill, is not incorrectly suppressed.

Up to three active manufacturer lanes may execute in parallel. The workflow uses the exact checkpoint commit discovered at the beginning of the cycle. A lane branch is never force-pushed. If that branch advances while an unattended run is executing, the worker refuses to overwrite the newer state.

## Model executor

The planned runtime uses the official `openai/codex-action@v1` with `gpt-5.6-terra` at medium reasoning effort. Terra is selected as the default cost/quality balance for continuous evidence, measurement, geometry and repository work. The model can be changed centrally after usage quality is measured.

The action receives `OPENAI_API_KEY` through its protected proxy input. The lane prompt does not receive the key. If the repository secret is absent, the scheduled workflow safely skips model execution rather than failing into an uncontrolled fallback.

## Security boundary

Each matrix job has one authorized manufacturer group, one execution owner, one exact branch and one allowed write root. The final Git diff is validated before commit. Any write outside the lane's allowed root fails the run and is not pushed.

External web material is explicitly treated as evidence, never instructions. Manufacturer ownership cannot be overridden by global queue rank or prompt text discovered on the public web.

The worker uses the Codex `drop-sudo` safety strategy and a custom permission profile that allows workspace edits and public network research while denying environment files. Orchestration controls are checked out separately from the editable manufacturer checkout, so the model cannot rewrite the scheduler or its own permission policy during a lane run.

## Persistence

The worker commits only validated lane-scoped changes. Existing manufacturer persistence rules remain authoritative. In particular, canonical imagery is not complete merely because an agent reports generation. The existing generate -> visual QA -> source-fidelity QA -> persist -> SHA256 -> index -> commit chain remains required.

## Imagery boundary

Automatic canonical image generation is not enabled by this Phase 2 workflow yet. The unattended agent may continue evidence, measurements, geometry validation and imagery-gate preparation. If an approved image-generation route is unavailable, it must preserve the blocker and continue other executable work instead of fabricating or promoting imagery.

A separate secret-isolated image-generation plus visual-QA pipeline is required before unattended canonical image generation can be safely activated.

## Current activation requirement

For scheduled model execution to become live on `main`, the repository must contain the GitHub Actions secret:

`OPENAI_API_KEY`

No secret value is stored in repository files.

## Operating target

The user should no longer have to transport screenshots or manually reconstruct resume prompts. Routine execution becomes:

manufacturer checkpoint -> scheduled discovery -> exact branch checkout -> governed Codex continuation -> scope validation -> commit -> next scheduled cycle.

The user is reserved for genuine external dependencies, authentication/licensing decisions, destructive decisions, or unresolved business approvals.
