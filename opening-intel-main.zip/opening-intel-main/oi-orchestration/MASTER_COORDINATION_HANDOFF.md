# OI Engineering → Master Coordination handoff

Phase 1 introduces a **dry-run-only** repository resume layer. It is designed to consume durable `PLATFORM_EXECUTION_LIMIT_REACHED` checkpoints without using the user as the transport mechanism.

## What Master Coordination can rely on

- Durable resume queue schema exists.
- Manufacturer ownership is validated before claim.
- Claims have heartbeat-based stale recovery.
- Platform-limit checkpoints produce stable resume/job IDs.
- Resume instructions are deterministic and include branch, commit, active row/identity, stage and first unfinished task.
- Dry-run execution is idempotent: completed checkpointed work is skipped.
- Paid/model execution is disabled.

## What is not enabled

- No external model/API executor.
- No credentials or secrets.
- No automatic writes from GitHub Actions back into manufacturer branches.
- No bypass of ChatGPT Work execution limits.

## Integration contract

When a manufacturer lane persists `PLATFORM_EXECUTION_LIMIT_REACHED`, Master Coordination should normalize it to the `PlatformLimitCheckpoint` schema and enqueue it in `oi-orchestration/WORKSTREAM_RESUME_QUEUE.json` (or a later API/store implementing the same schema).

The job must preserve the manufacturer's `authorized_manufacturer_group` and `execution_owner`. A future executor may claim only matching scope unless an explicit governed cross-workstream handoff is added.

Master Coordination should continue to treat manufacturer checkpoints/artifacts/commits as authoritative. The resume layer is orchestration metadata, not a replacement for product evidence controls.

## Phase 2 prerequisite

A true unattended worker requires an explicitly authorized external runtime and budget/secret policy. Phase 1 is safe to merge without enabling paid execution.
