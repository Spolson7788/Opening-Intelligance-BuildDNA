# Opening Intelligence canonical imagery queue

This directory is the persistent cross-manufacturer production-control layer for canonical imagery.

## State model

Allowed queue states are: PENDING_IMAGERY_GATE, READY_FOR_IMAGERY, IMAGERY_IN_PROGRESS, IMAGERY_QA, IMAGERY_COMPLETE, BLOCKED_GEOMETRY, BLOCKED_IDENTITY, SOURCE_IMAGE_ONLY, IMAGERY_NOT_APPLICABLE, and CONTROLLED_IMAGERY_HOLD.

READY_FOR_IMAGERY requires a controlled exact identity and sufficiently constrained geometry. Manufacturer source/technical assets never count as completed canonical six-view sets. Generated assets use provenance OI_DIRECTIONAL_DERIVED and may not establish product facts.

## Execution

Process READY items in governing priority order. Each accepted set requires six standalone views, individual and source-fidelity QA, a contact sheet, manifest/index updates, checkpoint and run-log updates, and a commit. A row hold never blocks another eligible row.

## Join control

Use canonical_product_id when assigned. If it is blank, use source_workstream + source_registry_row. Blank IDs are intentional and must not be fabricated.
