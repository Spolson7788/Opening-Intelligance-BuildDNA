import {openingLink,openingSVG,savedOpening,savedFields,oiPrintableDocument} from './shared.mjs';
// This controller only reads installed records. Schedule proposals cannot satisfy it.
export function createDashboardQR({client,openWindow=(...args)=>window.open(...args),origin=()=>location.origin,render=openingSVG}){
 let epoch=0,host=null;
 function clear(){epoch++;if(host)host.replaceChildren();host=null;}
 client.auth.onAuthStateChange(event=>{if(event==='SIGNED_OUT'||event==='SIGNED_IN'||event==='USER_UPDATED')clear();});
 function mount(target,context){
  clear();host=target;const token=epoch,doc=host.ownerDocument;let finished=null;
  const button=doc.createElement('button'),print=doc.createElement('button'),status=doc.createElement('p'),preview=doc.createElement('div'),size=doc.createElement('select');
  button.textContent='Finish opening';print.textContent='Print QR label';print.disabled=true;
  size.setAttribute('aria-label','QR label size');for(const value of ['2x2','2x3','3x4','4x6']){const option=doc.createElement('option');option.value=value;option.textContent=value.replace('x',' x ')+' inches';size.append(option);}
  status.setAttribute('role','status');status.textContent='Checks the door and hardware saved online for this facility and opening.';
  host.style.padding='18px 20px';host.append(button,status,preview,size,print);
  const active=()=>token===epoch&&host===target;
  async function check(){
   const {data:{session}}=await client.auth.getSession();if(!session?.user?.id)throw Error('Sign in before checking this opening.');
   const actor=session.user.id;
   const {data,error}=await client.from('openings').select(savedFields).eq('facility_id',context.fid).eq('opening_no',context.op);
   const again=await client.auth.getSession();if(!active())return null;
   if(again.data?.session?.user?.id!==actor)throw Error('Account changed. Finish the opening again.');
   if(error)throw Error('Could not verify the saved records online. Check your connection and try again.');
   return savedOpening(data,context);
  }
  button.onclick=async()=>{
   finished=null;print.disabled=true;preview.replaceChildren();button.disabled=true;status.textContent='Checking saved door and hardware.';
   try{const saved=await check();if(!saved||!active())return;finished=saved.fingerprint;status.textContent='Opening '+context.op+' is complete ('+saved.count+' hardware records + door saved online).';print.disabled=false;}
   catch(e){if(active())status.textContent=e.message;}finally{if(active())button.disabled=false;}
  };
  print.onclick=async()=>{
   if(!finished||!active())return;
   // Reserve a popup within the click gesture, then populate only after online revalidation.
   const popup=openWindow('','_blank','width=500,height=720');
   if(!popup){status.textContent='Allow pop-ups to open printer selection.';return;}
   print.disabled=true;const snapshot=finished;
   try{const saved=await check();if(!active()||!saved){popup.close();return;}
    if(saved.fingerprint!==snapshot){finished=null;throw Error('Saved records changed. Finish the opening again before generating its QR.');}
    const label={opening:context.op,facility:context.facility,svg:render(openingLink(context.fid,context.op,origin()))};
    preview.innerHTML=label.svg;popup.document.write(oiPrintableDocument(label,size.value.split('x').map(Number)));popup.document.close();popup.focus();popup.print();
    status.textContent='Choose a printer in the print dialog. OI cannot confirm physical printing.';
   }catch(e){popup.close();if(active()){finished=null;preview.replaceChildren();status.textContent=e.message;}}
   finally{if(active())print.disabled=!finished;}
  };
 }
 return {mount,clear};
}
