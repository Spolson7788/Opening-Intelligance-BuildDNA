// Shared Field/Dashboard identity, encoder settings and physical label layout.
export function openingLink(fid,op,origin=location.origin){return origin+'/#o='+encodeURIComponent(fid)+'~'+encodeURIComponent(op);}
export function openingSVG(link,encoder=globalThis.qrcode){const qr=encoder(0,'M');qr.addData(link);qr.make();return qr.createSvgTag({cellSize:5,margin:20,scalable:true});}
export const savedFields='id,facility_id,opening_no,component_class,manufacturer,model,verified_at,updated_at';
export function savedOpening(data,context){
 if(!Array.isArray(data))throw Error('Could not verify the saved records online.');
 const rows=data.filter(r=>r.facility_id===context.fid&&r.opening_no===context.op);
 if(!rows.some(r=>r.component_class==='DOOR'))throw Error('Save the door & frame online before finishing this opening.');
 const parts=rows.filter(r=>r.component_class&&r.component_class!=='DOOR');
 if(!parts.length)throw Error('No hardware is saved online for this opening. Add and save the hardware, then finish the opening.');
 return {count:parts.length,fingerprint:JSON.stringify(rows.sort((a,b)=>a.id.localeCompare(b.id)))};
}
export function oiPrintEscape(value){return String(value||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function oiPrintableDocument(label,size){
 const [w,h]=size;const title=oiPrintEscape('Opening '+label.opening),name=oiPrintEscape(label.facility);
 return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+' — QR label</title><style>@page{size:'+w+'in '+h+'in;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;color:#000;background:#fff}.label{width:'+w+'in;height:'+h+'in;padding:.16in;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.06in;overflow:hidden;text-align:center}.label h1{font-size:14pt;margin:0;overflow-wrap:anywhere}.facility{font-size:10pt;overflow-wrap:anywhere}.qr{width:100%;max-height:'+Math.max(1,h-1)+'in;aspect-ratio:1;padding:.06in;background:white}.qr svg{display:block;width:100%;height:100%}.hint{font-size:8pt}nav{padding:12px;max-width:440px;font-size:14px}button{padding:12px}@media print{nav{display:none}}'+(w===2&&h===2?'.label{padding:.08in;gap:.025in}.label h1{font-size:10pt;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}.facility{font-size:8pt;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}.qr{width:1.35in;height:1.35in;max-height:1.35in;padding:.02in;flex-shrink:0}.hint{font-size:6pt}':'')+'</style></head><body><nav><button onclick="window.print()">Find / select printer</button><p>Select the printer and matching label size. Disable browser headers and footers if offered. This page cannot confirm physical printing.</p></nav><main class="label"><h1>'+title+'</h1><div class="facility">'+name+'</div><div class="qr">'+label.svg+'</div><div class="hint">Scan to open this record</div></main></body></html>';
}
