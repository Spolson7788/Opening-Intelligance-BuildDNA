// Staging intentionally has no offline cache or fetch handler.
