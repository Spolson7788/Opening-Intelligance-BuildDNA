// Staging-only UI restrictions. Database grants remain the security boundary.
(() => {
  const selector = '#addFacBtn,#createFacBtn,#vendorFacBtn,#capbtn,#caplibbtn,#photo,#photolib,#addmore,[onclick*="identifyFrames("],[onclick*="visionFocus("],[onclick*="sendToPurchasing("],[onclick*="sendLogToPurchasing("]';
  const message = 'Unavailable in schedule QA staging';
  function disable() {
    document.querySelectorAll(selector).forEach(el => {
      if (!el.disabled) el.disabled = true;
      if (el.title !== message) el.title = message;
      if (el.getAttribute('aria-disabled') !== 'true') el.setAttribute('aria-disabled', 'true');
    });
  }
  document.addEventListener('click', event => {
    if (event.target.closest?.(selector)) { event.preventDefault(); event.stopImmediatePropagation(); }
  }, true);
  function start() {
    const notice = document.createElement('aside');
    notice.id = 'stagingNotice'; notice.setAttribute('role', 'note');
    notice.style.cssText = 'padding:12px;background:#fff3cd;color:#332701;font:14px sans-serif';
    notice.textContent = 'Schedule QA staging — private test environment; schedule import disabled. Use only the assigned QA facility. Facility creation, photo recognition and purchasing messages are unavailable. Schedule specifications remain separate from field-verified identity.';
    document.body.prepend(notice); disable();
    new MutationObserver(disable).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['disabled','onclick','id']});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();
})();
