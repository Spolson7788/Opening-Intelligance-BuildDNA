import {openingLink,openingSVG,savedOpening,savedFields} from '../qr/shared.mjs';
import {createDashboardQR} from '../qr/dashboard.mjs';
export const QA_FACILITY='8664b86a-af6d-444d-835a-16aa085f246e';
export const QA_MARK='QA-QR-TEST-001';
export function isFixture(row,enabled){return !!enabled&&row.facility_id===QA_FACILITY&&row.opening_no===QA_MARK;}
export function installFixturePanel({client,getFacility,enabled,doc=document}){
 if(!enabled)return;
 const panel=doc.createElement('aside'),title=doc.createElement('p'),button=doc.createElement('button'),status=doc.createElement('p'),qr=doc.createElement('div');
 title.textContent='Synthetic QR fixture — not installed; excluded from facility inventory and recognition statistics.';
 button.textContent='Prepare the single QA QR fixture';panel.append(title,button,status,qr);doc.body.append(panel);
 const previewButton=doc.createElement('button'),preview=doc.createElement('div');previewButton.textContent='Preview synthetic QR (no print)';panel.append(previewButton,preview);
 const controller=createDashboardQR({client});let generation=0;
 previewButton.onclick=async()=>{
  const fac=getFacility();if(fac?.id!==QA_FACILITY)return;const token=++generation;preview.replaceChildren();
  try{const before=await client.auth.getSession();if(!before.data?.session?.user?.id)throw Error('Sign in first.');
   const {data,error}=await client.from('openings').select(savedFields).eq('facility_id',fac.id).eq('opening_no',QA_MARK);
   const after=await client.auth.getSession();if(token!==generation||getFacility()?.id!==fac.id||before.data.session.user.id!==after.data?.session?.user?.id)return;
   if(error)throw error;savedOpening(data,{fid:fac.id,op:QA_MARK});preview.innerHTML=openingSVG(openingLink(fac.id,QA_MARK));
   status.textContent='Synthetic QA preview — not installed. No print dialog opened.';
  }catch(e){if(token===generation)status.textContent=e.message;}
 };
 client.auth.onAuthStateChange(()=>{generation++;controller.clear();status.textContent='';preview.replaceChildren();});
 button.onclick=async()=>{
  const fac=getFacility();if(fac?.id!==QA_FACILITY){status.textContent='Select the assigned Schedule Import QA facility.';return;}
  const token=++generation;button.disabled=true;controller.clear();
  try{const {error}=await client.rpc('oi_create_qa_qr_fixture');if(error)throw error;
   if(token!==generation||getFacility()?.id!==fac.id)return;
   status.textContent='Saved synthetic door and hardware. No recognition scan or local learning log was created.';
   controller.mount(qr,{fid:fac.id,op:QA_MARK,facility:'SYNTHETIC QA — NOT INSTALLED'});
  }catch(e){if(token===generation)status.textContent='Fixture unavailable: '+e.message;}finally{button.disabled=false;}
 };
 // Any facility change invalidates completion and print state.
 doc.addEventListener('change',event=>{if(!['facSel','facpick'].includes(event.target?.id))return;generation++;controller.clear();status.textContent='';preview.replaceChildren();});
}
