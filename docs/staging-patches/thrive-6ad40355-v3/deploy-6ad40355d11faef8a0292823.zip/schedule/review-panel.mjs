const LABEL='Schedule specified—field verification pending';
export function createReviewPanel({client,host,onChanged=()=>{}}){
 host.classList.add('oi-review');
 const doc=host.ownerDocument,el=(tag,text)=>{const n=doc.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
 let epoch=0,facility=null,busy=false,notice='',feedback=null;
 const interruptedNotice='Session refreshed during a decision. Its outcome is not confirmed. Review the refreshed status before retrying.';
 const tell=text=>{notice=text;if(feedback)feedback.textContent=text;};
 const clear=({preserveInterruption=false}={})=>{epoch++;host.replaceChildren();host.hidden=true;notice=preserveInterruption&&notice===interruptedNotice?notice:'';feedback=null;};
 const session=async()=>{const r=await client.auth.getSession();if(r.error||!r.data?.session)throw Error('Sign in to review.');return r.data.session;};
 const same=(a,b)=>a.user.id===b.user.id&&a.access_token===b.access_token;
 async function load(fid){
  const retained=fid===facility?notice:'';clear();notice=retained;facility=fid;if(!fid)return;const run=epoch;host.hidden=false;host.append(el('h2','Opening review'),el('p','Loading source and review history.'));
  try{
   const before=await session(),response=await client.rpc('oi_schedule_review_queue',{p_facility:fid}),after=await session();
   if(run!==epoch)return;if(!same(before,after))throw Error('Account changed. Reload review.');
   if(response.error)throw Error(response.error.message);const q=response.data;if(q.facility_id!==fid)throw Error('Facility mismatch.');
   host.replaceChildren(el('h2','Opening review'),el('p','Accept adds this opening to active inventory with field verification pending. Edit saves a pending facility-reported correction. Each opening requires its own decision.'));
   feedback=el('p',notice);feedback.setAttribute('role','status');feedback.setAttribute('aria-live','polite');feedback.dataset.reviewFeedback='';host.append(feedback);
   const cards=[],tabs=el('div');tabs.className='review-tabs';tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Opening review views');
   const panel=el('div');panel.id=(host.id||'opening-review')+'-results';panel.setAttribute('role','tabpanel');panel.tabIndex=0;
   let selected='pending';const tabButtons=[];
   const secondary=el('label','Other statuses ');secondary.className='review-secondary';secondary.hidden=true;
   const filter=el('select');filter.setAttribute('aria-label','Other opening statuses');
   for(const [value,label] of [['denied','Denied'],['template','Templates'],['all','All source rows']]){const option=el('option',label);option.value=value;filter.append(option);}secondary.append(filter);
   const empty=el('p');empty.setAttribute('role','status');panel.append(empty);
   const applyFilter=()=>{
    const value=selected==='other'?filter.value:selected;
    cards.forEach(({card,state})=>card.hidden=value!=='all'&&value!==state);
    for(const {button,value:key,label} of tabButtons){button.textContent=label+(key==='other'?'':' ('+cards.filter(c=>c.state===key).length+')');button.setAttribute('aria-selected',String(key===selected));button.tabIndex=key===selected?0:-1;}
    secondary.hidden=selected!=='other';panel.setAttribute('aria-labelledby',tabButtons.find(t=>t.value===selected).button.id);
    const label=value==='pending'?'Awaiting approval':value==='accepted'?'Accepted openings':filter.selectedOptions[0].textContent;
    empty.textContent=cards.some(({card})=>!card.hidden)?'':'No openings in “'+label+'”. Viewing a tab does not accept or verify an opening.';
   };
   for(const [value,label] of [['pending','Awaiting approval'],['accepted','Accepted openings'],['other','Other statuses']]){
    const button=el('button',label);button.type='button';button.id=panel.id+'-'+value;button.setAttribute('role','tab');button.setAttribute('aria-controls',panel.id);if(value==='other')button.className='review-other-tab';
    button.addEventListener('click',()=>{selected=value;applyFilter();});
    button.addEventListener('keydown',event=>{const i=tabButtons.findIndex(t=>t.button===button);let next;if(event.key==='ArrowRight')next=(i+1)%tabButtons.length;else if(event.key==='ArrowLeft')next=(i+tabButtons.length-1)%tabButtons.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabButtons.length-1;else return;event.preventDefault();selected=tabButtons[next].value;applyFilter();tabButtons[next].button.focus();});
    tabButtons.push({button,value,label});tabs.append(button);
   }
   filter.addEventListener('change',applyFilter);host.append(tabs,secondary,el('p','Tabs only change the view. Use the green Accept into active inventory button to approve an opening.'),panel);
   if(!q.can_review)host.append(el('p','Review decisions are not enabled for this account and facility.'));
   for(const batch of q.batches){
    if(batch.facility_id!==fid||batch.payload?.facility_id!==fid)throw Error('Batch facility mismatch.');
    for(const ex of batch.payload.exceptions||[]){const caveat=el('p',(ex.exception_id||ex.code||'Source caveat')+': '+(ex.message||ex.evidence?.summary||ex.code||'Review required'));caveat.className='review-caveat';host.insertBefore(caveat,panel);}
    for(const row of batch.payload.openings){
     const history=q.events.filter(e=>e.batch_id===batch.id&&e.source_row_id===row.source_row_id).sort((a,b)=>a.version-b.version),latest=history.at(-1);
     const state=latest?.state||'pending',effective=latest?.effective||{description_raw:row.source_row.description_raw,hardware:row.hardware};
     const card=el('article');card.dataset.sourceRowId=row.source_row_id;card.dataset.reviewState=row.disposition==='template'?'template':state;
     cards.push({card,state:row.disposition==='template'?'template':state});
     const heading=el('h3','Opening '+row.mark+' — '),badge=el('span',row.disposition==='template'?'template':state);badge.className='review-badge';heading.append(badge);
     card.append(heading,el('p','Source validation: '+row.disposition+'; '+LABEL),el('p','Source: '+row.source_row_id+'; revision '+(batch.payload.revision_raw||'unconfirmed')));
     for(const reason of row.reasons)card.append(el('p','Unresolved: '+reason));
     const source=el('details');source.className='review-source';source.append(el('summary','Immutable original source'),el('pre',JSON.stringify(row,null,2)));card.append(source);
     const description=el('input');description.value=effective.description_raw||'';const dl=el('label','Description ');dl.append(description);card.append(dl);
     description.readOnly=!q.can_review||row.disposition==='template'||state==='accepted';
     const inputs=[];
     for(const h of effective.hardware){
      const line=h.source_line,fields={source_line_id:line.source_line_id};const section=el('fieldset');section.append(el('legend',line.source_line_id+' — source-set quantity, leaf pending'));
      for(const key of ['quantity','description_raw','product_raw','manufacturer_raw']){const input=el('input');input.value=String(line[key]??'');input.readOnly=!q.can_review||row.disposition==='template'||state==='accepted';input.setAttribute('aria-label',key);if(key==='quantity'){input.type='number';input.min='0.01';input.max='10000';input.step='any';}const label=el('label',key.replaceAll('_',' ')+' ');label.append(input);section.append(label);fields[key]=input;}
      inputs.push(fields);card.append(section);
     }
     const note=el('p',latest?.correction?'Facility-reported correction — field verification pending.':'Schedule specified — field verification pending.');note.className='review-provenance';card.append(note);
     const verification=el('select');verification.setAttribute('aria-label','Field verification status for acceptance');
     const pending=el('option','Yet to be field verified');pending.value='pending';verification.append(pending);
     const complete=el('option','Field Verified Complete — use evidence review below');complete.value='complete';complete.disabled=true;verification.append(complete);
     const vl=el('label','Field verification status ');vl.append(verification);card.append(vl);
     const standardReason='Accepted into active inventory; field verification pending.';
     card.append(el('p','Acceptance reason: '+standardReason),el('p','Field verification is a separate evidence review. Acceptance does not confirm installed identity or condition.'));
     const reason=el('textarea');reason.setAttribute('aria-label','Decision or change reason');reason.maxLength=1900;const rl=el('label','Additional notes (optional for acceptance; required for denial or changes) ');rl.append(reason);card.append(rl);
     if(state==='accepted'){const link=el('a','Edit active opening or review field evidence');link.href='#oiOpeningAdmin';card.append(link,el('p','The values above preserve the accepted schedule version. Current facility corrections and verification appear in Opening edits and field verification below.'));}
     const status={set textContent(text){tell('Opening '+row.mark+': '+text);}};
     let retry=null;const controls=[],actions=el('div');actions.className='review-actions';card.append(actions);
     for(const action of ['accept','deny','edit']){
      const button=el('button',action==='edit'?'Save edit as pending':action==='accept'?'Accept into active inventory':'Deny');button.type='button';button.className='review-action review-'+action;
      const forbidden=!q.can_review||row.disposition==='template'||(action==='accept'&&(row.disposition!=='ready'||state!=='pending'))||(action==='deny'&&state==='denied')||(action==='edit'&&state==='accepted');
      button.disabled=forbidden;controls.push({button,forbidden});
      button.addEventListener('click',async()=>{
       if(busy||run!==epoch||forbidden)return;
       if(action!=='accept'&&reason.value.trim().length<5){status.textContent='Explain the denial or change in at least 5 characters.';return;}
       const decisionReason=action==='accept'?standardReason+(reason.value.trim()?' Notes: '+reason.value.trim():''):reason.value.trim();
       const patch=action==='edit'?{description_raw:description.value,hardware:inputs.map(f=>({source_line_id:f.source_line_id,quantity:Number(f.quantity.value),description_raw:f.description_raw.value,product_raw:f.product_raw.value,manufacturer_raw:f.manufacturer_raw.value}))}:{};
       if(action==='accept'&&(description.value!==(effective.description_raw||'')||inputs.some((f,i)=>['quantity','description_raw','product_raw','manufacturer_raw'].some(k=>String(f[k].value)!==String(effective.hardware[i].source_line[k]??''))))){status.textContent='Save your edits as pending before accepting that revision.';return;}
       const args={p_facility:fid,p_batch:batch.id,p_row:row.source_row_id,p_version:latest?.version||0,p_action:action,p_reason:decisionReason,p_patch:patch};
       busy=true;controls.forEach(c=>c.button.disabled=true);
       try{
        status.textContent='Saving decision…';
        const signature=JSON.stringify(args);if(retry?.signature!==signature)retry={signature,id:crypto.randomUUID()};args.p_request=retry.id;
        const now=await session();if(run!==epoch||facility!==fid||!same(before,now))throw Error('Account or facility changed. Reload review.');
        const result=await client.rpc('oi_review_opening',args);
        if(run!==epoch)return;if(result.error)throw Error(result.error.message);
        const confirmation=await client.rpc('oi_schedule_review_queue',{p_facility:fid});
        if(run!==epoch)return;if(!same(before,await session()))throw Error('Account changed. Reload review.');if(run!==epoch)return;
        if(confirmation.error)throw Error('Save returned, but confirmation failed: '+confirmation.error.message);
        const saved=confirmation.data?.events?.find(e=>e.request_id===args.p_request&&e.batch_id===batch.id&&e.source_row_id===row.source_row_id&&e.version===args.p_version+1&&e.action===action);
        if(confirmation.data?.facility_id!==fid||!saved||saved.state!==(action==='accept'?'accepted':action==='deny'?'denied':'pending'))throw Error('Saved decision is not yet confirmed in review history. Refresh before retrying.');
        if(confirmation.data.events.some(e=>e.batch_id===batch.id&&e.source_row_id===row.source_row_id&&e.version>saved.version))throw Error('Decision was recorded but has since changed. Refresh to review the latest status.');
        status.textContent=action==='accept'?'Accepted into active inventory. Field verification is still pending.':action==='deny'?'Denial saved.':'Changes saved as pending review.';
        await load(fid);if(facility===fid)await onChanged(fid);
       }catch(e){if(run===epoch)status.textContent='Decision not confirmed: '+e.message+'. Refresh on version conflict; retry unchanged input after an uncertain response.';}
       finally{busy=false;if(run===epoch)controls.forEach(c=>c.button.disabled=c.forbidden);}
      });actions.append(button);
     }
     const audit=el('details');audit.append(el('summary','Review history ('+history.length+')'));
     if(!history.length)audit.append(el('p','No review decisions recorded.'));
     for(const event of history){
      const entry=el('section');entry.append(el('h4','Version '+event.version+' · '+({accept:'Accepted into active inventory',deny:'Denied',edit:'Edited; pending review'}[event.action]||'Review decision')));
      entry.append(el('p',(event.created_at||'Time not recorded')+' · '+(event.actor_id?'Recorded by '+event.actor_id:'Reviewer not recorded')),el('p','Reason: '+(event.reason||'Not recorded')));
      const before=event.before_effective||{},after=event.effective||{};
      if(before.description_raw!==after.description_raw)entry.append(el('p','Description: '+(before.description_raw||'Not recorded')+' → '+(after.description_raw||'Not recorded')));
      for(const hardware of after.hardware||[]){const line=hardware.source_line,old=(before.hardware||[]).find(h=>h.source_line.source_line_id===line.source_line_id)?.source_line||{};
       for(const key of ['quantity','description_raw','manufacturer_raw','product_raw'])if(old[key]!==line[key])entry.append(el('p',(line.description_raw||'Hardware')+' · '+key.replaceAll('_',' ')+': '+(old[key]??'Not recorded')+' → '+(line[key]??'Not recorded')));
      }audit.append(entry);
     }
     card.append(audit);panel.append(card);
    }
    if(batch.payload.facility_supplies?.length)host.append(el('p',batch.payload.facility_supplies.length+' facility supplies are separate from opening decisions.'));
   }
   applyFilter();
   const refresh=el('button','Refresh opening review');refresh.type='button';refresh.onclick=()=>load(facility);host.append(refresh);
  }catch(e){if(run===epoch){host.replaceChildren(el('h2','Opening review unavailable'),el('p',e.message));}}
 }
 client.auth.onAuthStateChange?.(event=>{
  const interrupted=busy;
  clear();
  if(event==='SIGNED_IN'||event==='TOKEN_REFRESHED'){
   if(interrupted)notice=interruptedNotice;
   const fid=facility,run=epoch;
   if(fid)setTimeout(()=>{if(run===epoch)void load(fid);},0);
  }
 });
 return {load,clear};
}
