import {applyReviewed} from './apply-reviewed.mjs';
const LABEL='Schedule specified—field verification pending';
const HASH=/^[a-f0-9]{64}$/;
export async function inspectImport(payloadText,receipt,facilityId,actorId){
  const bytes=new TextEncoder().encode(payloadText);
  if(bytes.length>2_000_000)throw Error('Schedule file exceeds 2 MB.');
  const p=JSON.parse(payloadText);
  if(!receipt||!HASH.test(receipt.sha256)||!HASH.test(receipt.build)||receipt.actorId!==actorId||receipt.facilityId!==facilityId||receipt.batchId!==p.batch_id)throw Error('Review approval does not match this account, facility or batch.');
  const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(digest!==receipt.sha256)throw Error('Schedule file differs from the reviewed file.');
  if(p.schema_version!==1||p.identity_status!==LABEL||p.facility_id!==facilityId||!p.schedule_id||!Array.isArray(p.sources)||!Array.isArray(p.exceptions)||!Array.isArray(p.facility_supplies)||!Array.isArray(p.openings)||!p.openings.length||p.openings.length>150)throw Error('Invalid prepared schedule.');
  const ids=new Set();let ready=0;
  for(const r of p.openings){
    if(!r.source_row_id||ids.has(r.source_row_id)||typeof r.mark!=='string'||!r.source_row||!Array.isArray(r.reasons)||!Array.isArray(r.hardware)||!['ready','pending','template'].includes(r.disposition))throw Error('Invalid schedule row.');
    ids.add(r.source_row_id);if(r.disposition==='ready')ready++;
    if(r.disposition!=='ready'&&r.hardware.length)throw Error('Unresolved rows cannot contain hardware proposals.');
    for(const h of r.hardware)if(!h.source_line||typeof h.source_line.product_raw!=='string'||h.source_line.identity_status!==LABEL)throw Error('Invalid hardware proposal.');
  }
  if(ready>20)throw Error('At most 20 resolved openings per reviewed batch.');
  return {payloadText,receipt:{...receipt},document:p,actorId,facilityId};
}

export function createImportPanel({client,host,onApplied=()=>{}}){
  const doc=host.ownerDocument;
  const el=(tag,text)=>{const n=doc.createElement(tag);if(text!==undefined)n.textContent=text;if(tag==='p')n.style.whiteSpace='pre-wrap';return n;};
  let facility=null,epoch=0,candidate=null,busy=false;
  const open=el('button','Import door & hardware schedule');open.type='button';
  const body=el('div');body.hidden=true;
  const note=el('p','Choose the prepared schedule and its review approval file. Files stay in this browser until you confirm. Excel, PDF and Word sources must first be normalized and reviewed.');
  const file=el('input');file.type='file';file.accept='.json,application/json';
  const receipt=el('input');receipt.type='file';receipt.accept='.json,application/json';
  const a=el('label','Prepared schedule ');a.append(file);const b=el('label',' Review approval file ');b.append(receipt);
  const preview=el('button','Preview schedule');preview.type='button';
  const confirm=el('button','Confirm reviewed import');confirm.type='button';confirm.disabled=true;
  const cancel=el('button','Cancel');cancel.type='button';
  const status=el('p');status.setAttribute('role','status');const detail=el('div');
  body.append(note,a,b,preview,detail,confirm,cancel,status);host.append(open,body);host.hidden=true;
  const invalidate=()=>{epoch++;candidate=null;confirm.disabled=true;detail.replaceChildren();status.textContent='';};
  function setFacility(next){invalidate();facility=next;file.value='';receipt.value='';body.hidden=true;host.hidden=!next||next.role!=='admin';}
  open.addEventListener('click',()=>{body.hidden=!body.hidden;});
  cancel.addEventListener('click',()=>{invalidate();body.hidden=true;});
  file.addEventListener('change',invalidate);receipt.addEventListener('change',invalidate);
  preview.addEventListener('click',async()=>{
    if(busy)return;invalidate();const run=epoch,fac=facility;
    try{
      if(!fac||fac.role!=='admin'||!file.files[0]||!receipt.files[0])throw Error('Choose both reviewed files for the selected facility.');
      if(file.files[0].size>2_000_000||receipt.files[0].size>8192)throw Error('File exceeds the allowed size.');
      const {data,error}=await client.auth.getSession();if(error||!data?.session)throw Error('Sign in before previewing.');
      const next=await inspectImport(await file.files[0].text(),JSON.parse(await receipt.files[0].text()),fac.id,data.session.user.id);
      if(run!==epoch)return;
      candidate=next;const p=next.document;
      detail.append(el('h3','Review for '+fac.name),el('p',LABEL),el('p',p.openings.length+' opening rows; '+p.openings.flatMap(r=>r.hardware).length+' hardware proposals; '+p.facility_supplies.length+' separate facility supplies.'));
      for(const s of p.sources)detail.append(el('p',s.filename+' — revision '+(s.revision||'unconfirmed')));
      for(const ex of p.exceptions)detail.append(el('p',ex.message||ex.code||'Source review required'));
      for(const r of p.openings){detail.append(el('p','Opening '+r.mark+' — '+r.disposition+'; '+r.source_row_id+'; configuration '+r.source_row.configuration+'; leaf '+(r.source_row.leaf_assignment||'pending')));for(const reason of r.reasons)detail.append(el('p',reason));for(const h of r.hardware)detail.append(el('p',h.source_line.quantity_raw+' × '+h.source_line.description_raw+' — '+h.source_line.product_raw));}
      confirm.disabled=false;status.textContent='Confirmation still requires the matching server review permit. Installed records remain unchanged.';
    }catch(e){if(run===epoch)status.textContent=e.message;}
  });
  confirm.addEventListener('click',async()=>{
    if(busy||!candidate)return;
    const c=candidate,run=epoch;busy=true;confirm.disabled=true;preview.disabled=true;
    try{
      const {data,error}=await client.auth.getSession();
      if(error||!data?.session||data.session.user.id!==c.actorId||facility?.id!==c.facilityId||run!==epoch)throw Error('Account or facility changed. Preview again.');
      const result=await applyReviewed(client,{facilityId:c.facilityId,payloadText:c.payloadText,sha256:c.receipt.sha256,build:c.receipt.build,beforeDispatch:()=>{
        if(run!==epoch||facility?.id!==c.facilityId||candidate!==c)throw Error('Preview changed before submission. Preview again.');
      }});
      if(run!==epoch)return;
      if(result.status==='created'||result.status==='already_applied'){
        candidate=null;status.textContent=result.status==='created'?'Schedule imported. Field verification remains pending.':'This exact schedule was already imported; no duplicate created.';await onApplied(c.facilityId);
      }else if(result.status==='review_required'){
        candidate=null;status.textContent='Schedule differs from the existing batch. Review required; nothing overwritten.';
        const diff=el('details');diff.append(el('summary','Existing and proposed schedule'));
        diff.append(el('pre',JSON.stringify({existing:result.existing,proposed:result.proposed},null,2)));detail.append(diff);
      }else throw Error('Import result was not recognized. Verify batch status before retrying.');
    }catch(e){if(run===epoch)status.textContent=/reviewed_payload_required|staging_import_disabled/.test(e.message)?'Awaiting review approval. No import was authorized.':'Import not confirmed: '+e.message+' Refresh the schedule before retrying the same reviewed file.';}
    finally{busy=false;preview.disabled=false;if(run===epoch)confirm.disabled=!candidate;}
  });
  client.auth.onAuthStateChange?.(()=>{invalidate();file.value='';receipt.value='';body.hidden=true;});
  return {setFacility};
}
