const LABEL='Schedule specified—field verification pending';
function element(doc,tag,text){const e=doc.createElement(tag);if(text!==undefined)e.textContent=String(text);return e;}
export function createSchedulePanel({client,host}){
  const doc=host.ownerDocument;
  let epoch=0,facilityId=null,mark='';
  function clear(){epoch++;host.replaceChildren();host.hidden=true;}
  function heading(){host.hidden=false;host.replaceChildren(element(doc,'h2','Pending schedule review'),element(doc,'p',LABEL),element(doc,'p','Source readiness is not facility acceptance or field verification. Per-opening decisions are not yet enabled.'));}
  async function load(fid,openingMark=''){
    clear();facilityId=fid;mark=openingMark;
    if(!fid)return;
    const run=epoch;
    heading();host.append(element(doc,'p','Loading schedule…'));
    try{
      const before=await client.auth.getSession();const session=before.data?.session;
      if(!session)throw Error('signin');
      const result=await client.from('oi_schedule_batches').select('id,payload').eq('facility_id',fid);
      const after=await client.auth.getSession();const next=after.data?.session;
      if(run!==epoch)return;
      if(!next||session.user.id!==next.user.id||session.access_token!==next.access_token)throw Error('account_changed');
      if(result.error)throw Error('unavailable');
      heading();let count=0;
      for(const batch of result.data||[]){
        const p=batch.payload;
        if(p?.facility_id!==fid||p.identity_status!==LABEL)throw Error('invalid_scope');
        const rows=(p.openings||[]).filter(r=>!openingMark||r.mark===openingMark);
        if(!rows.length)continue;
        count+=rows.length;
        host.append(element(doc,'p','Batch '+p.batch_id+' · Revision: '+(p.revision_raw||'unconfirmed')));
        for(const e of p.exceptions||[])host.append(element(doc,'p',(e.exception_id||e.code||'Source exception')+': '+(e.message||e.code||'Review required')));
        for(const row of rows){
          const card=element(doc,'article');card.className='oi-schedule-row';
          card.dataset.sourceRowId=row.source_row_id;
          card.append(element(doc,'h3','Opening '+row.mark));
          card.append(element(doc,'p',row.disposition==='template'?'Reusable template — not an individual installed opening.':'Facility review: pending — no per-opening decision recorded.'));
          card.append(element(doc,'p','Source validation: '+(row.disposition==='ready'?'resolved for review':row.disposition==='template'?'template':'unresolved')));
          card.append(element(doc,'p',row.source_row.description_raw||''));
          card.append(element(doc,'p','Configuration: '+row.source_row.configuration+' · Leaf assignment: '+(row.source_row.leaf_assignment||'pending')));
          card.append(element(doc,'p','Source: '+row.source_row_id+' · Group: '+(row.source_row.group_raw||'pending')));
          if(row.reasons.length)card.append(element(doc,'p','Pending: '+row.reasons.join(', ')));
          if(row.disposition==='template')card.append(element(doc,'p','Reusable type — individual unit/opening assignment pending.'));
          const list=element(doc,'ul');
          for(const h of row.hardware){
            const l=h.source_line;const item=element(doc,'li');
            item.dataset.proposalId=h.proposal_id;
            item.append(element(doc,'span',l.quantity_raw+' × '+l.description_raw+' — '+l.manufacturer_raw+' — '));
            const raw=element(doc,'span',l.product_raw);raw.style.whiteSpace='pre-wrap';item.append(raw);
            item.append(element(doc,'small',' · '+l.source_line_id+' · source set quantity · leaf '+(l.leaf_assignment||'pending')));
            list.append(item);
          }
          card.append(list);
          // An import permit only admitted source material. Until durable facility
          // decisions exist, no row here may seed active records or QR completion.
          host.append(card);
        }
        if(p.facility_supplies?.length)host.append(element(doc,'p',p.facility_supplies.length+' facility supplies retained separately; no installed hardware created.'));
      }
      if(!count)host.append(element(doc,'p',openingMark?'No schedule rows for this opening.':'No schedule imported for this facility.'));
      const refresh=element(doc,'button','Refresh schedule');refresh.type='button';refresh.addEventListener('click',()=>load(facilityId,mark));host.append(refresh);
    }catch(_){if(run!==epoch)return;heading();host.append(element(doc,'p','Schedule unavailable. Sign in or refresh after access is restored. Installed records are unchanged.'));}
  }
  client.auth.onAuthStateChange?.(event=>{
    if(event==='SIGNED_OUT'){clear();return;}
    if(event==='SIGNED_IN'||event==='TOKEN_REFRESHED'){
      clear();const fid=facilityId,openingMark=mark,run=epoch;
      // Supabase auth callbacks run under its auth lock. Defer getSession until it releases.
      if(fid)setTimeout(()=>{if(run===epoch)void load(fid,openingMark);},0);
    }
  });
  return {load,clear};
}
