// Call only from the existing authenticated application session after operator review.
// Database authorization remains authoritative; this helper grants no permission.
export async function applyReviewed(client,{facilityId,payloadText,sha256,build,beforeDispatch=()=>{}}){
  if(!facilityId||!build||!payloadText||!/^[a-f0-9]{64}$/.test(sha256))throw Error('Exact reviewed artifact and build required');
  const bytes=new TextEncoder().encode(payloadText);
  const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(digest!==sha256)throw Error('Reviewed artifact changed');
  const p=JSON.parse(payloadText);
  if(p.facility_id!==facilityId)throw Error('Facility mismatch');
  // Synchronous final context check after hashing, with no await before dispatch.
  beforeDispatch();
  const {data,error}=await client.rpc('oi_apply_schedule_batch',{p_facility:facilityId,p_payload_text:payloadText,p_build:build});
  if(error)throw error;
  return data;
}
