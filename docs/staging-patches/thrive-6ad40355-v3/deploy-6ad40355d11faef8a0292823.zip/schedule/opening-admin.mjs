const fields=['description_raw','manufacturer_raw','product_raw','quantity','area','fire_rated','notes'];
const title={description_raw:'Description',manufacturer_raw:'Manufacturer',product_raw:'Product / model',quantity:'Quantity',area:'Installed area / location',fire_rated:'Fire-rated designation',notes:'Routine notes'};
export function createOpeningAdmin({client,host,onChanged=()=>{}}){
 const doc=host.ownerDocument,el=(tag,text)=>{const e=doc.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
 host.classList.add('oi-review');let epoch=0,facility=null,busy=false;
 const clear=()=>{epoch++;host.replaceChildren();host.hidden=true;};
 const session=async()=>{const r=await client.auth.getSession();if(r.error||!r.data?.session)throw Error('Sign in to manage openings.');return r.data.session;};
 const same=(a,b)=>a?.user.id===b?.user.id&&a?.access_token===b?.access_token;
 async function load(fid){
  clear();facility=fid;if(!fid)return null;const run=epoch;host.hidden=false;host.append(el('h2','Opening edits and field verification'));
  try{
   const before=await session(),r=await client.rpc('oi_opening_admin_queue',{p_facility:fid}),after=await session();
   if(run!==epoch)return null;if(!same(before,after))throw Error('Account changed. Reload the Dashboard.');if(r.error)throw Error(r.error.message);
   const q=r.data;if(q.facility_id!==fid)throw Error('Facility mismatch.');
   host.append(el('p','Facility admins can maintain active openings here. Source schedules and independently saved field records remain in the audit trail. Material corrections invalidate only the affected verification; routine notes do not. Health assessment and recognition approval remain separate.'));
   if(!q.can_edit)host.append(el('p','You can view these records. Editing and verification require this facility’s authorized admin.'));
   if(!q.openings.length)host.append(el('p','No openings available for this facility. The synthetic QR fixture is excluded.'));
   for(const opening of q.openings){
    const card=el('article'),heading=el('h3','Opening '+opening.opening_no+' — '),badge=el('span',opening.verification_status==='field_verified_complete'?'Field Verified Complete':'Yet to be field verified');badge.className='review-badge';heading.append(badge);card.append(heading);
    card.dataset.openingNo=opening.opening_no;card.dataset.reviewState=opening.verification_status==='field_verified_complete'?'accepted':'pending';
    const editable=q.can_edit&&opening.active;
    if(!opening.active)card.append(el('p','Pending or denied source opening: edit and approve it in Opening review above. Field verification becomes available after acceptance.'));
    card.append(el('p','Version '+opening.version+'. These are facility-maintained details; source wording is preserved separately.'));
    const controls=[],componentInputs=new Map(),evidenceInputs=new Map();
    const field=(label,input,parent)=>{const l=el('label',label+' ');l.append(input);parent.append(l);controls.push(input);return input;};
    for(const [key,component] of Object.entries(opening.components)){
     const section=el('fieldset');section.append(el('legend',component.kind+' — '+component.description_raw));const values={};
     for(const name of fields){const input=el(name==='notes'?'textarea':name==='fire_rated'?'select':'input');input.setAttribute('aria-label',key+' '+title[name]);input.disabled=!editable;
      if(name==='fire_rated'){for(const [value,label] of [['null','Unknown'],['true','Yes'],['false','No']]){const option=el('option',label);option.value=value;input.append(option);}input.value=String(component[name]??null);}else{input.value=String(component[name]??'');if(name==='quantity'){input.type='number';input.min='0.01';input.max='10000';input.step='any';}else input.maxLength=name==='notes'?2000:1000;}
      values[name]=field(title[name],input,section);
     }
     componentInputs.set(key,values);
     const verified=opening.verification?.[key];
     section.append(el('p',verified?'Evidence recorded by '+verified.actor_id+' at '+verified.verified_at+'.':'This component has no current field verification.'));
     const detail=el('details');detail.append(el('summary','Record physical evidence for this component'));
     detail.append(el('p','Inspect the actual opening and each listed unit. If it differs, save the correction first. Confirming schedule text alone is not field verification. Unknown attributes remain unknown; this does not certify fire compliance, health, or recognition identity.'));
     const photo=el('select');photo.disabled=!editable;photo.append(Object.assign(el('option','Choose your saved photo'),{value:''}));
     for(const p of opening.photos||[]){const option=el('option',p.taken_at+' — '+p.storage_path);option.value=p.id;photo.append(option);}field('Evidence photo',photo,detail);
     const preview=el('div');detail.append(preview);let photoRun=0;
     photo.addEventListener('change',async()=>{const selection=++photoRun;preview.replaceChildren();const selected=opening.photos.find(p=>p.id===photo.value);if(!selected)return;
      try{const signed=await client.storage.from('opening-photos').createSignedUrl(selected.storage_path,60);if(run!==epoch||selection!==photoRun||!same(before,await session()))return;if(signed.error)throw Error(signed.error.message);
       const image=el('img');image.src=signed.data.signedUrl;image.alt='Selected field evidence photo';image.style.maxWidth='100%';image.style.maxHeight='320px';preview.append(image);
      }catch(e){if(run===epoch&&selection===photoRun)preview.textContent='Photo preview unavailable: '+e.message;}
     });
     const location=el('input');location.disabled=!editable;location.maxLength=500;field('Physical location / leaf(s) inspected',location,detail);
     const coverage=el('input');coverage.type='number';coverage.min='0.01';coverage.step='any';coverage.disabled=!editable;field('Number of units physically checked',coverage,detail);
     const notes=el('textarea');notes.disabled=!editable;notes.maxLength=2000;field('Observed evidence and differences',notes,detail);
     const confirm=el('input');confirm.type='checkbox';confirm.disabled=!editable;field('I physically checked these details and all units covered by this component',confirm,detail);
     evidenceInputs.set(key,{photo,location,coverage,notes,confirm});section.append(detail);card.append(section);
    }
    const upload=el('details');upload.append(el('summary','Add a field evidence photo'),el('p','Upload an actual photo of this opening. Uploading does not mark anything verified or send it for recognition. Save any edits first; adding a photo reloads this panel.'));
    const file=el('input');file.type='file';file.accept='image/jpeg,image/png,image/webp';file.disabled=!editable;upload.append(file);
    const uploadButton=el('button','Upload evidence photo');uploadButton.type='button';uploadButton.disabled=!editable;upload.append(uploadButton);controls.push(uploadButton,file);card.append(upload);
    const reason=el('textarea');reason.maxLength=2000;reason.disabled=!editable;field('Reason for change or evidence review (required)',reason,card);
    const status=el('p');status.setAttribute('role','status');card.append(status);let retry=null;
    const values=()=>Object.fromEntries([...componentInputs].map(([key,inputs])=>[key,Object.fromEntries(fields.map(name=>[name,name==='fire_rated'?JSON.parse(inputs[name].value):name==='quantity'?Number(inputs[name].value):inputs[name].value]))]));
    const patch=()=>{const result={};for(const [key,entry] of Object.entries(values())){const changed=Object.fromEntries(Object.entries(entry).filter(([name,value])=>value!==opening.components[key][name]));if(Object.keys(changed).length)result[key]=changed;}return result;};
    const locked=()=>busy||run!==epoch||!editable;
    const lock=()=>{busy=true;controls.forEach(c=>c.disabled=true);};
    const unlock=()=>{busy=false;if(run===epoch)controls.forEach(c=>c.disabled=!editable);};
    async function save(action){
     if(locked())return;const changes=patch();if(reason.value.trim().length<5){status.textContent='Explain this change or evidence review in at least 5 characters.';return;}
     if(action==='edit'&&!Object.keys(changes).length){status.textContent='No changes to save.';return;}
     const evidence=[];
     if(action==='verify'){
      if(Object.keys(changes).length){status.textContent='Save the changed details first, then verify the saved version.';return;}
      for(const [key,input] of evidenceInputs){if(!input.confirm.checked)continue;
       if(!input.photo.value||input.location.value.trim().length<3||input.notes.value.trim().length<5||Number(input.coverage.value)!==opening.components[key].quantity){status.textContent='Each checked component needs its photo, location, evidence notes, and coverage of its full quantity.';return;}
       const {notes,...observed}=opening.components[key];evidence.push({component_key:key,photo_id:input.photo.value,observed,location:input.location.value.trim(),coverage_quantity:Number(input.coverage.value),notes:input.notes.value.trim()});
      }
      if(!evidence.length){status.textContent='Select at least one physically checked component and supply its evidence.';return;}
     }
     const args={p_facility:fid,p_opening:opening.opening_no,p_version:opening.version,p_base_digest:opening.base_digest,p_action:action,p_reason:reason.value.trim(),p_patch:action==='edit'?changes:{},p_evidence:evidence};
     const signature=JSON.stringify(args);if(retry?.signature!==signature)retry={signature,id:crypto.randomUUID()};args.p_request=retry.id;lock();
     try{if(!same(before,await session())||run!==epoch)throw Error('Account changed. Reload before saving.');const response=await client.rpc('oi_manage_opening',args);if(run!==epoch)return;if(response.error)throw Error(response.error.message);await load(fid);if(facility===fid)await onChanged(fid);}
     catch(e){if(run===epoch)status.textContent='Save not confirmed: '+e.message+'. Reload on a version conflict; retry unchanged input if the response was lost.';}finally{unlock();}
    }
    const actions=el('div');actions.className='review-actions';
    for(const [action,label] of [['edit','Save facility edits'],['verify','Record checked field evidence']]){const b=el('button',label);b.type='button';b.disabled=!editable;b.className='review-action review-edit';b.addEventListener('click',()=>save(action));actions.append(b);controls.push(b);}card.append(actions);
    uploadButton.addEventListener('click',async()=>{
     if(locked())return;const selected=file.files?.[0];if(!selected||!['image/jpeg','image/png','image/webp'].includes(selected.type)||selected.size>5242880){status.textContent='Choose a JPEG, PNG or WebP photo up to 5 MB.';return;}
     if(Object.keys(patch()).length){status.textContent='Save or discard your edits before adding a photo.';return;}lock();
     try{if(!same(before,await session())||run!==epoch)throw Error('Account changed.');const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'}[selected.type],path=fid+'/'+encodeURIComponent(opening.opening_no)+'/'+crypto.randomUUID()+'.'+ext;
      const stored=await client.storage.from('opening-photos').upload(path,selected,{contentType:selected.type,upsert:false});if(stored.error)throw Error(stored.error.message);
      if(run!==epoch||!same(before,await session()))throw Error('Account changed; photo attachment was not completed.');
      const attached=await client.from('opening_photos').insert({facility_id:fid,opening_no:opening.opening_no,storage_path:path});if(attached.error)throw Error('Photo uploaded but attachment not confirmed: '+attached.error.message);await load(fid);
     }catch(e){if(run===epoch)status.textContent=e.message;}finally{unlock();}
    });
    const events=opening.history||[],legacy=opening.legacy_history||[];
    const audit=el('details');audit.append(el('summary','Edit and verification history ('+(events.length+legacy.length)+')'));
    if(!events.length&&!legacy.length)audit.append(el('p','No edits or field verification recorded.'));
    const showChanges=(parent,before,after)=>{
     const flatten=(value,prefix='')=>Object.entries(value||{}).flatMap(([key,v])=>v&&typeof v==='object'&&!Array.isArray(v)?flatten(v,prefix+key+' / '):[[prefix+key,v]]);
     const old=new Map(flatten(before)),next=new Map(flatten(after));
     for(const key of new Set([...old.keys(),...next.keys()]))if(JSON.stringify(old.get(key))!==JSON.stringify(next.get(key))){
      const display=v=>v==null?'Not recorded':typeof v==='object'?'Updated details':String(v);
      parent.append(el('p',key.replaceAll('_',' ')+': '+display(old.get(key))+' → '+display(next.get(key))));
     }
    };
    for(const event of [...events,...legacy]){
     const entry=el('section');entry.append(el('h4',(event.action==='verify'?'Field evidence recorded':event.action==='edit'?'Facility details edited':'Independent field record '+(event.operation||'changed'))+(event.version?' · Version '+event.version:'')));
     entry.append(el('p',(event.created_at||'Time not recorded')+' · '+(event.actor_id?'Recorded by '+event.actor_id:'System record')));
     if(event.reason)entry.append(el('p','Reason: '+event.reason));
     showChanges(entry,event.before_value,event.after_value);audit.append(entry);
    }
    card.append(audit);
    const sourceDetails=el('details');sourceDetails.append(el('summary','Source references (technical details)'),el('pre',JSON.stringify(opening.source_refs||[],null,2)));card.append(sourceDetails);host.append(card);
   }
   return q;
  }catch(e){if(run===epoch)host.append(el('p','Opening management unavailable: '+e.message));return null;}
 }
 client.auth.onAuthStateChange?.(event=>{clear();if(event==='SIGNED_IN'||event==='TOKEN_REFRESHED'){const fid=facility,run=epoch;if(fid)setTimeout(()=>{if(run===epoch)void load(fid);},0);}});
 return {load,clear};
}
