// These records belong in the main inventory, but never in field health/verification
// metrics or QR queries, which continue to use independently saved public.openings.
export function reportedInventory(records,installed,facilityId){
 const marks=new Set(installed.map(r=>r.opening_no));
 const valid=records.filter(r=>r.facility_id===facilityId&&r.active===true&&r.verification_status==='field_verification_pending');
 const standalone=valid.filter(r=>!marks.has(r.opening_no));
 return {records:valid,additionalOpenings:new Set(standalone.map(r=>r.opening_no)).size,
  additionalParts:standalone.reduce((n,r)=>n+r.effective.hardware.length,0),installedMarks:marks};
}
function appendBaselineRows(host,inventory){
 const doc=host.ownerDocument;
 for(const r of inventory.records){
  const tr=doc.createElement('tr'),td=doc.createElement('td');td.colSpan=6;tr.dataset.reportedOpeningId=r.id;
  const h=doc.createElement('h3');h.textContent='Opening '+r.opening_no+' — active, field verification pending';td.append(h);
  const note=doc.createElement('p');note.textContent=(r.provenance==='facility_reported_correction'?'Facility-reported correction':'Accepted schedule specification')+'; '+r.effective.description_raw+'; source '+r.source_row_id;td.append(note);
  if(inventory.installedMarks.has(r.opening_no)){const p=doc.createElement('p');p.textContent='An independently saved record also exists above. This report is retained for comparison and is not counted twice.';td.append(p);}
  const ul=doc.createElement('ul');for(const h of r.effective.hardware){const li=doc.createElement('li'),l=h.source_line;li.textContent=l.quantity_raw+' × '+l.description_raw+' — '+l.manufacturer_raw+' — '+l.product_raw+'; leaf pending';ul.append(li);}td.append(ul);
  const p=doc.createElement('p');p.textContent='Health and field verification have not been assessed. QR eligibility requires independently saved door and hardware records.';td.append(p);tr.append(td);host.append(tr);
 }
}

export function appendReportedRows(host,inventory,adminData=null){
 if(!adminData){appendBaselineRows(host,inventory);return;}
 const managed=adminData.openings.filter(o=>o.active),marks=new Set(managed.map(o=>o.opening_no));
 appendBaselineRows(host,{...inventory,records:inventory.records.filter(r=>!marks.has(r.opening_no))});
 const doc=host.ownerDocument;
 for(const o of managed){
  if(!inventory.records.some(r=>r.opening_no===o.opening_no)&&!o.history?.length)continue;
  const tr=doc.createElement('tr'),td=doc.createElement('td');td.colSpan=6;tr.dataset.managedOpening=o.opening_no;
  const h=doc.createElement('h3');h.textContent='Opening '+o.opening_no+' - current facility-maintained details';td.append(h);
  const badge=doc.createElement('p');badge.textContent=o.verification_status==='field_verified_complete'?'Field Verified Complete':'Yet to be field verified';td.append(badge);
  for(const [key,c] of Object.entries(o.components)){const line=doc.createElement('p');line.textContent=c.quantity+' x '+c.description_raw+' - '+c.manufacturer_raw+' - '+c.product_raw+'; '+(o.verification[key]?'field evidence recorded':'field verification pending');td.append(line);}
  const p=doc.createElement('p');p.textContent='Current facility corrections are shown here. Original schedule and field records remain in the audit trail. Health, recognition approval and QR eligibility remain separate. An independently saved record of the same opening is not counted twice.';td.append(p);tr.append(td);host.append(tr);
 }
}
